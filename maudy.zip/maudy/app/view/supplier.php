<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Supplier</title>
    <style>
        /* Gaya CSS */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        nav {
            background-color: #444;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        .supplier {
            background-color: #fff;
            border: 1px solid #ddd;
            padding: 20px;
            margin-bottom: 20px;
        }

        .supplier h2 {
            margin-top: 0;
        }

        .supplier ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .supplier li {
            margin-bottom: 10px;
        }

        .supplier li a {
            text-decoration: none;
            color: #333;
            display: block;
            padding: 5px;
            transition: background-color 0.3s ease;
        }

        .supplier li a:hover {
            background-color: #f4f4f4;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Daftar Supplier</h1>
</header>
<nav>
    <a href="../index.php">Beranda</a>
</nav>

<div class="container">
    <div class="supplier">
        <h2>Supplier 1</h2>
        <ul>
            <li><a href="produk.php?supplier=supplier1">Produk dari Supplier 1</a></li>
            <li><a href="produk.php?supplier=supplier1">Produk dari Supplier 1</a></li>
            <li><a href="produk.php?supplier=supplier1">Produk dari Supplier 1</a></li>
        </ul>
    </div>

    <div class="supplier">
        <h2>Supplier 2</h2>
        <ul>
            <li><a href="produk.php?supplier=supplier2">Produk dari Supplier 2</a></li>
            <li><a href="produk.php?supplier=supplier2">Produk dari Supplier 2</a></li>
            <li><a href="produk.php?supplier=supplier2">Produk dari Supplier 2</a></li>
        </ul>
    </div>

    <!-- Tambahkan supplier lainnya di sini -->
</div>

<footer>
    <p>Hak Cipta &copy; Pengembangan Layan WEB. 2143009_Maudy Shofiyah.</p>
</footer>

</body>
</html>
