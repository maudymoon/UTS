<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Utama E-Commerce</title>
    <style>
        /* Gaya CSS */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav {
            background-color: #444;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 10px;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        .product {
            float: left;
            width: 25%;
            padding: 20px;
            box-sizing: border-box;
        }

        .product img {
            max-width: 100%;
            height: auto;
        }

        .product h3 {
            margin-top: 0;
        }

        .product p {
            margin-bottom: 0;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Selamat Datang di Toko Beauty's</h1>
</header>

<nav>
    <a href="index.php">Beranda</a>
    <a href="view/kategori.php">Kategori</a>
    <a href="view/supplier.php">Supplier</a>
    <a href="view/transaksi.php">Transaksi</a>
</nav>

<div class="container">
    <div class="product">
        <img src="../img/gambar_npure.jpeg" alt="Produk 1">
        <h3>Produk 1</h3>
        <p>Harga: Rp249.000</p>
        <button>Beli Sekarang</button>
    </div>
    <div class="product">
        <img src="../img/gambar_g2g.jpeg" alt="Produk 2">
        <h3>Produk 2</h3>
        <p>Harga: Rp161.000</p>
        <button>Beli Sekarang</button>
    </div>
    <div class="product">
        <img src="../img/gambar_msglow.jpeg" alt="Produk 3">
        <h3>Produk 3</h3>
        <p>Harga: Rp300.000</p>
        <button>Beli Sekarang</button>
    </div>
    <div class="product">
        <img src="../img/gambar_scarlett.jpeg" alt="Produk 4">
        <h3>Produk 4</h3>
        <p>Harga: Rp264.000</p>
        <button>Beli Sekarang</button>
    </div>
    <!-- tambahkan produk lainnya di sini -->
</div>

<footer>
    <p>Hak Cipta &copy; Pengembangan Layan WEB. 2143009_Maudy Shofiyah.</p>
</footer>

</body>
</html>
